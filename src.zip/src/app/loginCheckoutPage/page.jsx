"use client";

import CategorySidebar from "@/components/CategorySidebar";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import ProductHeading from "@/components/ProductHeading";
import ProductListing from "@/components/ProductListing";
import MegaMenu from "@/components/Megamenu";
import React from "react";

const loginCheckoutPage = () => {
  return (
    <>
      <Header />
      <MegaMenu />
   
      <div  style={{
                 background:"#f1f1f1",
                }}>

            <div className='header-product bg-white'>
      
      <h1>Login or Checkout as a Guest</h1>

    </div>


    
      <div className="container">
        <div className="login-signup">
         <div className="row">
           <div className="col-md-6">
              <div className="login-sec">

                <h2>Login</h2>
                <p>If you have an account, please log in.</p>

                <div className="col-md-12">
                    <input type="text" placeholder="Email*"></input>
              </div>

               <div className="col-md-12">
                    <input type="password" placeholder="Password*"></input>
              </div>

              <div className="row">
                <div className="col-md-6">
                  <a href="#">Forgot your password?</a>

                </div>
                <div className="col-md-6">
                  <div className="float-right">
                      <button className="btn-cart">Login</button>
                 </div>
                </div>
                
              </div>

              </div>
           </div>
           












         <div className="col-md-6">
              <div className="login-sec register">

                <h2>Checkout as a Guest or Register</h2>
                <p>Register with us for future convenience:</p>

                <div className="col-md-12">
                  <div className="check-register"><input type="radio" /> Checkout As Guest</div>
                   <div className="check-register"><input type="radio" /> Register</div>

                   <a href="#" className="mt-1 mb-1">Register & Save time!</a>
                   <p className="pb-0 mb-0">– Fast and easy checkout</p>
                   <p>– Easy access to your history and status</p>
              </div>

              

              <div className="row">
               
                <div className="col-md-12">
                 
                      <button className="btn-cart">Continue</button>
               
                </div>
                
              </div>

              </div>
           </div>





         </div>
          
       </div> 
        
      </div>
    </div>
     
  
      <Footer />
    </>
  );
};

export default loginCheckoutPage;