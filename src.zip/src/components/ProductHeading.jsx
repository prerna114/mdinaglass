import React from 'react'

function ProductHeading() {
  return (
    <div className='header-product'>
      <h5>SHOP</h5>
      <h1>Sets</h1>


    </div>
  )
}

export default ProductHeading