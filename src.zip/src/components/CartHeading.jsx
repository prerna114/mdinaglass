import React from 'react'

function CartHeading() {
  return (
    <div className='header-product'>
      
      <h1>My Shopping Cart</h1>
     <h5>Fast and Secure Shopping at Mdina Glass</h5>

    </div>
  )
}

export default CartHeading